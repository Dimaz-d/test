let overlay = document.querySelector('.overlay');

document.querySelector('.main-button').addEventListener('click',() =>  {openModal()});


function openModal(){
    console.log("show")
    overlay.classList.remove("hide")
    overlay.classList.add("show")
}
overlay.addEventListener('click', (el)=> {
    if(overlay.classList.contains("show")){
        console.log(el.target);
        if(overlay == el.target){
            closeModal();
        }
    }
})

function closeModal(){
    console.log("hide");
    overlay.classList.add("hide")
    overlay.classList.remove("show")
    
}
